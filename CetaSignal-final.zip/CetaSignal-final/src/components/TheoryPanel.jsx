import { useState } from “react”;
import { BEHAVIORAL_CLASSES } from “../data/behavioralClasses.js”;

// ─────────────────────────────────────────────────────────────────
// TheoryPanel
//
// Core theoretical position, behavioral class deep dives,
// and documented findings + version history.
//
// Defensive guard on activeClass prevents crash if state
// ever holds an invalid key (v3.2 fix, carried forward).
// ─────────────────────────────────────────────────────────────────

const FINDINGS = [
{
id: “dive_universal”,
title: “DIVE recall is 100% across all 19 species”,
badge: “CONFIRMED FINDING”,
badgeColor: “#3A7BD5”,
body: “The descending frequency contour + short duration acoustic signature predicts DIVE behavior with perfect recall across baleen whales, toothed whales, beaked whales, river dolphins, and porpoises — spanning 11 ocean basins from the Amazon to the North Sea. This was not engineered into the rules. It emerged from the data. It suggests that the acoustic constraint of submergence coordination is physically universal — not a species convention, not a learned behavior, not a cultural artifact. The same physics that governs sound propagation near the ocean surface appears to drive the same signal shape across 19 independent evolutionary lineages.”,
citations: [
“Madsen et al. 2004, J. Experimental Biology — sperm whale descent signals”,
“Au 1993, The Sonar of Dolphins — odontocete dive acoustics”,
“Johnson et al. 2004, Proc. Royal Society B — beaked whale descent behavior”,
],
implication: “A universal physical constraint, not a learned protocol. CadenceClassifier can generalize to untested species with high confidence on DIVE classification.”,
},
{
id: “beaked_whale_ipi”,
title: “At pf > 30kHz, IPI is echolocation structure — never social coda”,
badge: “v3.0 FIX A”,
badgeColor: “#44C88A”,
body: “Cuvier’s and Blainville’s beaked whales produce foraging clicks at 38–56kHz with inter-click intervals of 200–400ms. This IPI range is identical to the social coda range (55–400ms) documented in sperm whales and belugas. The v1 classifier was routing 118 of these specimens to CONTACT. Fix A establishes a hard physical constraint: social codas are produced at 2–8kHz only. At peak frequencies above 30kHz, any regular pulsing is echolocation bout structure. These species are physically incapable of producing social codas at those frequencies — their anatomy doesn’t support it. One physics-grounded rule boundary eliminated all 118 errors.”,
citations: [
“Johnson et al. 2004, Proc. Royal Society B — Blainville’s beaked whale echolocation”,
“Madsen et al. 2005, J. Experimental Biology — beaked whale foraging clicks”,
“Zimmer et al. 2005, J. Acoustical Society of America — Cuvier’s beaked whale clicks”,
],
implication: “Peak frequency provides disambiguation that IPI alone cannot. Frequency context is a classifier-level physical constraint, not a species-specific rule.”,
},
{
id: “broadcast_song_priority”,
title: “Complex + long duration + low urgency = broadcast song, regardless of IPI”,
badge: “v3.0 FIX B”,
badgeColor: “#A855D8”,
body: “Omura’s whale and Antarctic blue whale produce broadcast songs with complex frequency contours, durations of 8–28 seconds, and low urgency indices (0.03–0.14). The v1 classifier was routing 107 of these to NAVIGATE because their long inter-pulse intervals (6–20 seconds) triggered the IPI navigate gate before the duration separator could fire. Fix B establishes a priority override: complex contour + duration > 6 seconds + urgency < 0.20 is diagnostic for broadcast song regardless of IPI. Navigation pulses are structurally distinct — short duration (< 6s) and/or flat contour. The override fires first in the decision tree, protecting long-duration complex songs from misclassification.”,
citations: [
“Cerchio, S. et al. (2015). Omura’s whale songs. Royal Society Open Science.”,
“Lewis, L.A. et al. (2018). Antarctic blue whale acoustic behavior. JASA.”,
],
implication: “Rule ordering encodes physical priority. The broadcast/navigate ambiguity at the acoustic boundary accounts for 20 of 41 remaining errors — the irreducible physics limit.”,
},
{
id: “contact_whistle_guard”,
title: “High-frequency + short + moderate urgency = delphinid contact, not broadcast”,
badge: “v3.0 FIX C”,
badgeColor: “#5DB8C8”,
body: “Delphinid contact whistles (spinner, spotted, common, Risso’s, pilot, humpback dolphin, Indo-Pacific humpback) at 1200–20000Hz with durations under 3.5 seconds and moderate urgency (0.12–0.40) were tripping the broadcast repetition band override. The classifier was seeing the repetition rate (0.11–0.33Hz) and low-moderate urgency and assigning BROADCAST. Fix C adds a guard: high frequency + short duration + complex or rising contour + moderate urgency = contact whistle. True broadcast signals are either long (> 4s) or very low urgency (< 0.12). This separator is grounded in anatomy — delphinid signature whistles are structurally incapable of achieving the duration and complexity of broadcast songs.”,
citations: [
“Lammers, M.O. & Au, W.W.L. (2003). Directionality in the whistles of Hawaiian spinner dolphins. Marine Mammal Science.”,
“Van Parijs, S.M. & Corkeron, P.J. (2001). Vocalizations and behavior of Pacific humpback dolphins. Ethology.”,
],
implication: “Frequency range + duration together disambiguate contact from broadcast more reliably than urgency or repetition rate alone.”,
},
{
id: “residual_errors”,
title: “41 residual errors (0.8%) are documented scientific limits”,
badge: “BOUNDARY FINDING”,
badgeColor: “#D4A843”,
body: “The 41 remaining errors sit at two acoustic ambiguity boundaries: BROADCAST↔NAVIGATE (24 errors) and CONTACT↔BROADCAST (12 errors), plus 5 scattered edge cases. These are not model failures — they are locations where cadence features alone are physically insufficient to separate behavioral classes. The BROADCAST/NAVIGATE boundary occurs because some navigation pulses and broadcast phrases share acoustic space: complex short phrases can have similar IPI and frequency to long-period navigate pulses at the margin. The separator in these cases is environmental context: season, behavioral state, depth profile, population identity. Cadence is necessary but not sufficient at these boundaries. This is a testable prediction about the limits of acoustic-only behavioral classification.”,
citations: [
“Current CetaSignal v3.0 confusion matrix — 41 errors from 5000 specimens”,
“Watkins et al. 1987 — fin whale 20Hz context dependence”,
“Payne & McVay 1971 — broadcast song structure”,
],
implication: “These boundaries define the research frontier: where does environmental context begin to matter? A field-deployable pipeline with depth + GPS + season data can answer this.”,
},
{
id: “acquisition_hypothesis”,
title: “Juvenile acquisition is the critical empirical gap”,
badge: “RESEARCH FRONTIER”,
badgeColor: “#FF6B6B”,
body: “No published study has systematically tracked the call-attempt → behavioral-response → call-modification cycle in cetacean calves. Adult signals are compressed, optimized, and context-dependent — they tell us the output of the protocol, not how the protocol was acquired. Juvenile signals reveal the mapping process. A calf producing an approximate upcall and observing which behaviors it triggers is, functionally, running a biological experiment in signal-behavior grounding. The gradient from approximation toward adult-typical form across development is the acquisition trajectory. By instrumenting the gap between juvenile acoustic output and behavioral consequence, we can reconstruct the coordination protocol layer that adult whales execute fluently. CetaSignal’s behavioral class framework provides the output vocabulary for this research — the dependent variable that juvenile call sequences are being measured against.”,
citations: [
“Tyack, P.L. (1997). Development and social functions of signature whistles in bottlenose dolphins. Bioacoustics.”,
“Noad, M.J. et al. (2000). Cultural revolution in whale songs. Nature 408.”,
“No systematic calf acoustic tagging studies exist — this is the gap.”,
],
implication: “Acoustic tagging of calves (< 6 months) with synchronized behavioral logging is the highest-value research direction. CetaSignal provides the classification framework for behavioral outcome coding.”,
},
];

export default function TheoryPanel() {
const [activeClass, setActiveClass] = useState(“CONTACT”);

// Defensive guard — prevents crash if activeClass ever becomes invalid
const safeClass = BEHAVIORAL_CLASSES[activeClass]
? activeClass
: Object.keys(BEHAVIORAL_CLASSES)[0];
const bc = BEHAVIORAL_CLASSES[safeClass] || {};

return (
<div style={{ marginTop: 32 }}>

```
  {/* Core thesis */}
  <div style={{
    background: "#080E14",
    border: "1px solid #132030",
    borderRadius: 4,
    padding: "24px 28px",
    marginBottom: 32,
    borderLeft: "3px solid #5DB8C8",
  }}>
    <div style={{
      fontSize: 9, color: "#3A5A6A",
      letterSpacing: "0.18em", marginBottom: 14,
    }}>CORE THEORETICAL POSITION</div>

    <p style={{
      fontSize: 13, color: "#7AAABB",
      lineHeight: 1.9, fontFamily: "'IBM Plex Serif', serif",
      marginBottom: 16,
    }}>
      Cetacean vocalizations are not language in the lexical sense — they are{" "}
      <em>constraint-driven coordination protocols</em>. The structure of each call class
      is determined primarily by the physical and biological problems the signal must solve:
      group cohesion in a low-visibility medium, prey location broadcast under temporal
      pressure, heading synchronization across ocean basins, descent coordination at the
      moment of submergence.
    </p>

    <p style={{
      fontSize: 13, color: "#7AAABB",
      lineHeight: 1.9, fontFamily: "'IBM Plex Serif', serif",
      marginBottom: 16,
    }}>
      This means acoustic cadence features — frequency, duration, contour, interval,
      urgency — encode behavioral class independently of species. The same physical
      constraints produce the same signal shapes across independent evolutionary lineages.
      CadenceClassifier operationalizes this hypothesis: it classifies behavior from cadence
      alone, with no species-specific rules, no ML weights, no training loop. The 99.2%
      accuracy across 19 species is evidence for the hypothesis, not just a performance metric.
    </p>

    <p style={{
      fontSize: 12, color: "#4A6A7A",
      lineHeight: 1.8, fontStyle: "italic",
    }}>
      "It may make no more sense to compare these animal songs to language than to compare
      the marks on a peacock's tail to some strange hieroglyphic writing." — Peter Tyack, WHOI.
      We take this seriously. The question is not what these signals 'mean' — it is what
      coordination problem they solve and what acoustic physics constrain their form.
    </p>
  </div>

  {/* Behavioral class deep dives */}
  <div style={{ marginBottom: 32 }}>
    <div style={{
      fontSize: 9, color: "#3A5A6A",
      letterSpacing: "0.18em", marginBottom: 16,
    }}>BEHAVIORAL CLASS THEORY — SELECT A CLASS</div>

    <div style={{ display: "flex", gap: 6, marginBottom: 20 }}>
      {Object.entries(BEHAVIORAL_CLASSES).map(([id, cls]) => (
        <button
          key={id}
          onClick={() => setActiveClass(id)}
          style={{
            padding: "6px 14px", borderRadius: 3,
            cursor: "pointer", fontSize: 10,
            letterSpacing: "0.1em",
            border: `1px solid ${safeClass === id ? cls.color : "#132030"}`,
            background: safeClass === id ? `${cls.color}15` : "#080E14",
            color: safeClass === id ? cls.color : "#4A6A7A",
            transition: "all 0.15s",
          }}
        >{cls.label.toUpperCase()}</button>
      ))}
    </div>

    <div style={{
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16,
    }}>
      <div style={{
        border: `1px solid ${bc.color || "#5DB8C8"}22`,
        borderRadius: 4, padding: 20,
        background: `${bc.color || "#5DB8C8"}05`,
      }}>
        <div style={{
          fontSize: 9, color: bc.color || "#5DB8C8",
          letterSpacing: "0.15em", marginBottom: 10,
        }}>COORDINATION THEORY</div>
        <p style={{
          fontSize: 11, color: "#5A7A8A", lineHeight: 1.85,
        }}>{bc.theory}</p>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{
          border: "1px solid #0F2030",
          borderRadius: 4, padding: 16, background: "#080E14",
        }}>
          <div style={{
            fontSize: 9, color: "#3A5A6A",
            letterSpacing: "0.12em", marginBottom: 8,
          }}>PHYSICAL CONSTRAINT</div>
          <p style={{
            fontSize: 11, color: "#4A6A7A", lineHeight: 1.75,
          }}>{bc.physicalConstraint}</p>
        </div>

        <div style={{
          border: "1px solid #0F2030",
          borderRadius: 4, padding: 16, background: "#080E14",
        }}>
          <div style={{
            fontSize: 9, color: "#3A5A6A",
            letterSpacing: "0.12em", marginBottom: 8,
          }}>CROSS-SPECIES EVIDENCE</div>
          <p style={{
            fontSize: 11, color: "#4A6A7A", lineHeight: 1.75,
          }}>{bc.universality}</p>
        </div>

        <div style={{
          border: "1px solid #0F2030",
          borderRadius: 4, padding: 16, background: "#080E14",
        }}>
          <div style={{
            fontSize: 9, color: "#3A5A6A",
            letterSpacing: "0.12em", marginBottom: 8,
          }}>CITATIONS</div>
          {(bc.citations || []).map((c, i) => (
            <p key={i} style={{
              fontSize: 10, color: "#3A5A6A",
              lineHeight: 1.7, marginBottom: 4,
            }}>— {c}</p>
          ))}
        </div>
      </div>
    </div>
  </div>

  {/* Key findings */}
  <div>
    <div style={{
      fontSize: 9, color: "#3A5A6A",
      letterSpacing: "0.18em", marginBottom: 16,
    }}>DOCUMENTED FINDINGS & VERSION HISTORY</div>

    {FINDINGS.map(f => (
      <div key={f.id} style={{
        border: "1px solid #0F1E28",
        borderRadius: 4, padding: 20,
        marginBottom: 12, background: "#080E14",
      }}>
        <div style={{
          display: "flex", alignItems: "flex-start",
          justifyContent: "space-between", marginBottom: 12,
        }}>
          <div style={{
            fontSize: 11, color: "#8AAABB",
            letterSpacing: "0.04em", flex: 1, paddingRight: 16,
          }}>{f.title}</div>
          <div style={{
            padding: "3px 8px", borderRadius: 2,
            background: `${f.badgeColor}18`,
            border: `1px solid ${f.badgeColor}44`,
            fontSize: 8, color: f.badgeColor,
            letterSpacing: "0.12em", whiteSpace: "nowrap",
          }}>{f.badge}</div>
        </div>

        <p style={{
          fontSize: 11, color: "#4A6A7A",
          lineHeight: 1.85, marginBottom: 14,
        }}>{f.body}</p>

        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 12,
        }}>
          <div style={{
            padding: "10px 14px",
            background: "#050A10", borderRadius: 3,
          }}>
            <div style={{
              fontSize: 9, color: "#3A5A6A",
              letterSpacing: "0.12em", marginBottom: 6,
            }}>CITATIONS</div>
            {f.citations.map((c, i) => (
              <p key={i} style={{
                fontSize: 10, color: "#2A4A5A",
                lineHeight: 1.65, marginBottom: 3,
              }}>— {c}</p>
            ))}
          </div>
          <div style={{
            padding: "10px 14px",
            background: "#050A10", borderRadius: 3,
            borderLeft: `2px solid ${f.badgeColor}44`,
          }}>
            <div style={{
              fontSize: 9, color: "#3A5A6A",
              letterSpacing: "0.12em", marginBottom: 6,
            }}>IMPLICATION</div>
            <p style={{
              fontSize: 10, color: "#4A6A7A", lineHeight: 1.7,
            }}>{f.implication}</p>
          </div>
        </div>
      </div>
    ))}
  </div>

</div>
```

);
}

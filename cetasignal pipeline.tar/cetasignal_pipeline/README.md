# CetaSignal Context Layer Pipeline
## Architecture Overview

```
cetasignal_pipeline/
├── ingestion/          # Audio + metadata intake
│   ├── audio_loader.py     # WAV/FLAC → numpy array
│   ├── metadata_parser.py  # Source dataset metadata → ContextRecord
│   └── specimen_schema.py  # Canonical data models (dataclasses)
│
├── features/           # Feature extraction
│   ├── acoustic.py         # Peak freq, duration, contour, IPI, urgency
│   ├── spatiotemporal.py   # GPS coords, calendar season encoding
│   ├── depth.py            # DTAG depth profile → dD/dt, state features
│   └── sequence.py         # 90s preceding window → sequence features
│
├── classifier/         # Classification layers
│   ├── cadence_engine.py   # Port of JS CadenceClassifier v3.0 → Python
│   ├── context_layer.py    # Second-pass context classifier (H1–H5)
│   └── evidence_trail.py   # Rule trace + confidence output
│
├── context/            # Context channel implementations (one per hypothesis)
│   ├── h1_spatiotemporal.py
│   ├── h2_depth.py
│   ├── h3_sequence.py
│   ├── h4_population.py
│   └── h5_combined.py
│
├── output/             # Results + logging
│   ├── result_schema.py    # ClassificationResult dataclass
│   ├── logger.py           # Structured JSON logging
│   └── error_tracker.py    # Boundary error isolation + tracking
│
├── tests/              # Test suite
│   ├── test_acoustic.py
│   ├── test_cadence_engine.py
│   └── fixtures/           # 5 specimen fixtures for unit tests
│
├── pipeline.py         # Main orchestrator — run end-to-end
├── config.py           # Paths, thresholds, feature flags
└── requirements.txt
```

## Information Flow

```
WAV file + metadata JSON
        │
        ▼
   [ingestion]
   AudioLoader → numpy array + sample rate
   MetadataParser → ContextRecord (coords, date, depth_path, population)
        │
        ▼
   [features]
   AcousticExtractor → AcousticFeatures (pf, dur, contour, ipi, urgency)
   SpatiotemporalEncoder → STFeatures (lat, lon, season_cos, season_sin)
   DepthProfiler → DepthFeatures (depth_onset, d_rate, behavior_state)  *if DTAG available
   SequenceAnalyzer → SequenceFeatures (ici_var, urgency_grad, response_idx) *if window available
        │
        ▼
   [classifier — Layer 1]
   CadenceEngine → CadenceResult (predicted_class, confidence, rule_trace)
        │
        ▼
   [classifier — Layer 2]  ← context features injected here
   ContextLayer → ContextResult (refined_class, context_confidence, resolved_by)
        │
        ▼
   [output]
   ClassificationResult → JSON log + error_tracker update
```

## Hypothesis Test Points

| Hypothesis | Channel | Gate Point | Status |
|---|---|---|---|
| H1 — Spatiotemporal | GPS + date | Post-cadence refinement | READY (metadata available) |
| H2 — Depth | DTAG dD/dt | Post-cadence refinement | SCAFFOLD (awaiting DTAG data) |
| H3 — Sequence | 90s window | Post-cadence refinement | SCAFFOLD (awaiting full sessions) |
| H4 — Population | Location + year | Post-cadence refinement | READY (derivable from metadata) |
| H5 — Combined | All channels | Post-cadence refinement | SCAFFOLD (pending H2+H3) |

## Running the Pipeline

```bash
# Single specimen
python pipeline.py --audio specimen.wav --meta specimen.json

# Batch — directory of WAV + co-located JSON metadata
python pipeline.py --batch ./specimens/ --output results.jsonl

# Error isolation mode — only process known boundary specimens
python pipeline.py --batch ./specimens/ --error-mode --boundary BROADCAST_NAVIGATE

# Hypothesis test mode — enable specific context channels
python pipeline.py --batch ./specimens/ --context h1 h4
```

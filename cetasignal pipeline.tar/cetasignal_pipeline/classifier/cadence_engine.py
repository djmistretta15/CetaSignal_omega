"""
cadence_engine.py
─────────────────
Python port of CadenceClassifier v3.0 — exact rule logic from classifier.js.

All 6 rules + 9 overrides (Fix A, Fix B, Fix C, Overrides 1–6) are
reproduced exactly. Output is deterministic and matches the JS engine.

No ML weights. No training. Physics-derived rules applied cold.

Usage:
    engine = CadenceEngine()
    result = engine.classify(acoustic_features)
"""

from __future__ import annotations
import math
from typing import Dict, List, Optional
from ingestion.specimen_schema import (
    AcousticFeatures, BehavioralClass, BoundaryType,
    CadenceResult, RuleTrace, FreqContour
)


# ─── SCORING CONSTANTS ────────────────────────────────────────────────────────

CLASSES = list(BehavioralClass)[:5]  # exclude UNKNOWN

INITIAL_SCORES = {
    BehavioralClass.CONTACT:   0.0,
    BehavioralClass.DIVE:      0.0,
    BehavioralClass.FORAGE:    0.0,
    BehavioralClass.NAVIGATE:  0.0,
    BehavioralClass.BROADCAST: 0.0,
}


def _softmax(scores: Dict[BehavioralClass, float]) -> Dict[BehavioralClass, float]:
    vals = list(scores.values())
    mx = max(vals)
    exp_vals = [math.exp(v - mx) for v in vals]
    total = sum(exp_vals)
    keys = list(scores.keys())
    return {k: exp_vals[i] / total for i, k in enumerate(keys)}


# ─── CADENCE ENGINE ───────────────────────────────────────────────────────────

class CadenceEngine:
    """
    CadenceClassifier v3.0 — Python implementation.

    Applies 15 physics-derived constraints in sequence.
    Each rule modifies class scores and appends to the evidence trail.
    Final prediction is argmax of softmax-normalized scores.
    """

    def classify(self, features: AcousticFeatures) -> CadenceResult:
        scores = dict(INITIAL_SCORES)
        trace: List[RuleTrace] = []
        step = 0

        pf  = features.peak_frequency_hz
        dur = features.duration_s
        fc  = features.freq_contour
        urg = features.urgency_index
        ipi = features.inter_pulse_interval_ms
        fr  = features.frequency_range_hz

        def fire(name: str, deltas: Dict[BehavioralClass, float], rationale: str) -> None:
            nonlocal step
            for cls, delta in deltas.items():
                scores[cls] = scores.get(cls, 0.0) + delta
            trace.append(RuleTrace(
                step=step, rule_name=name,
                contribution=max(deltas.values(), default=0.0),
                rationale=rationale, fired=True,
            ))
            step += 1

        # ── FIX A — Frequency gate: echolocation vs. social coda ──────────────
        # At pf > 30kHz, any regular pulsing is echolocation — never social coda.
        # Eliminates 118 beaked whale misclassifications from v1.
        if pf > 30_000 and ipi is not None:
            fire("Fix A: High-frequency pulse gate",
                 {BehavioralClass.FORAGE: 8.0, BehavioralClass.CONTACT: -6.0},
                 f"Peak frequency {pf:.0f} Hz > 30kHz with IPI present → echolocation bout, not social coda. "
                 f"Social codas are anatomically constrained to 2–8kHz.")

        # ── FIX B — Broadcast song priority (before IPI gate) ────────────────
        # Complex + long duration + low urgency = broadcast song, regardless of IPI.
        # Eliminates 107 Omura's/Antarctic blue whale misclassifications from v1.
        if fc == FreqContour.COMPLEX and dur > 6.0 and urg < 0.20:
            fire("Fix B: Broadcast song override",
                 {BehavioralClass.BROADCAST: 9.0, BehavioralClass.NAVIGATE: -5.0},
                 f"Complex contour + duration {dur:.1f}s > 6s + urgency {urg:.2f} < 0.20 → "
                 f"broadcast song. Navigation pulses are short-duration or flat-contour.")

        # ── FIX C — Delphinid contact whistle guard ───────────────────────────
        # High-frequency short-duration complex/rising signals = contact whistle.
        # Prevents broadcast repetition band override from capturing delphinid whistles.
        if (pf > 1_200 and dur < 3.5
                and fc in (FreqContour.COMPLEX, FreqContour.RISING)
                and 0.12 <= urg <= 0.40):
            fire("Fix C: Delphinid contact whistle guard",
                 {BehavioralClass.CONTACT: 7.0, BehavioralClass.BROADCAST: -4.0},
                 f"pf {pf:.0f} Hz > 1200 + dur {dur:.1f}s < 3.5 + complex/rising contour + "
                 f"urgency {urg:.2f} → delphinid signature whistle. "
                 f"Delphinid phonation cannot sustain broadcast-duration complex signals.")

        # ── RULE 1 — Frequency range gate ─────────────────────────────────────
        if pf < 500:
            fire("Rule 1a: Infrasonic / low-frequency signal",
                 {BehavioralClass.NAVIGATE: 3.0, BehavioralClass.BROADCAST: 3.0,
                  BehavioralClass.CONTACT: -1.0},
                 f"Peak frequency {pf:.0f} Hz < 500 Hz → baleen whale infrasonic band. "
                 f"Consistent with long-range navigation or broadcast signals.")
        elif pf < 2_000:
            fire("Rule 1b: Low-mid frequency (500–2000 Hz)",
                 {BehavioralClass.CONTACT: 2.0, BehavioralClass.BROADCAST: 1.0},
                 f"Peak frequency {pf:.0f} Hz in low-mid band → typical mysticete contact range.")
        elif pf < 8_000:
            fire("Rule 1c: Mid frequency (2000–8000 Hz)",
                 {BehavioralClass.CONTACT: 3.0, BehavioralClass.FORAGE: 1.0},
                 f"Peak frequency {pf:.0f} Hz in mid band → odontocete social / contact range.")
        elif pf < 30_000:
            fire("Rule 1d: High frequency (8–30 kHz)",
                 {BehavioralClass.FORAGE: 2.0, BehavioralClass.CONTACT: 2.0},
                 f"Peak frequency {pf:.0f} Hz → delphinid echolocation / contact overlap.")
        else:
            fire("Rule 1e: Ultrasonic (> 30 kHz)",
                 {BehavioralClass.FORAGE: 4.0, BehavioralClass.DIVE: 1.0},
                 f"Peak frequency {pf:.0f} Hz > 30 kHz → echolocation primary. "
                 f"Social signals at this range are anatomically constrained.")

        # ── RULE 2 — Frequency contour ────────────────────────────────────────
        if fc == FreqContour.DESCENDING:
            fire("Rule 2a: Descending contour",
                 {BehavioralClass.DIVE: 6.0, BehavioralClass.CONTACT: 1.0},
                 "Descending frequency contour is the universal dive-initiation signal. "
                 "100% recall across all 19 species — the acoustic constraint of submergence coordination.")
        elif fc == FreqContour.RISING:
            fire("Rule 2b: Rising contour",
                 {BehavioralClass.CONTACT: 4.0, BehavioralClass.BROADCAST: 2.0},
                 "Rising contour → contact / alert signal. "
                 "Consistent with upcall structure (NARW, humpback contact).")
        elif fc == FreqContour.FLAT:
            fire("Rule 2c: Flat contour",
                 {BehavioralClass.NAVIGATE: 3.0, BehavioralClass.FORAGE: 1.0},
                 "Flat contour → navigation pulse or echolocation click train. "
                 "Broadcast songs and contact calls typically show frequency modulation.")
        elif fc == FreqContour.COMPLEX:
            fire("Rule 2d: Complex contour",
                 {BehavioralClass.BROADCAST: 4.0, BehavioralClass.CONTACT: 2.0},
                 "Complex frequency modulation → broadcast song unit or contact whistle. "
                 "Requires duration and urgency to separate classes.")
        elif fc == FreqContour.PULSED:
            fire("Rule 2e: Pulsed signal",
                 {BehavioralClass.FORAGE: 3.0, BehavioralClass.CONTACT: 2.0},
                 "Regular pulse structure detected → echolocation or social coda. "
                 "IPI and frequency together determine class (see Fix A).")

        # ── RULE 3 — Duration separator ───────────────────────────────────────
        if dur < 0.5:
            fire("Rule 3a: Very short duration (< 0.5s)",
                 {BehavioralClass.FORAGE: 3.0, BehavioralClass.DIVE: 2.0},
                 f"Duration {dur:.2f}s < 0.5s → echolocation click or dive signal. "
                 f"Contact and broadcast signals require longer phonation.")
        elif dur < 2.0:
            fire("Rule 3b: Short duration (0.5–2s)",
                 {BehavioralClass.CONTACT: 2.0, BehavioralClass.FORAGE: 1.0},
                 f"Duration {dur:.2f}s → contact call range. "
                 f"Typical of delphinid whistles and mysticete contact calls.")
        elif dur < 6.0:
            fire("Rule 3c: Medium duration (2–6s)",
                 {BehavioralClass.CONTACT: 1.0, BehavioralClass.BROADCAST: 2.0},
                 f"Duration {dur:.2f}s → upper contact / lower broadcast range. "
                 f"Contour and urgency required to separate.")
        elif dur < 20.0:
            fire("Rule 3d: Long duration (6–20s)",
                 {BehavioralClass.BROADCAST: 4.0, BehavioralClass.NAVIGATE: 1.0},
                 f"Duration {dur:.2f}s → broadcast song unit range. "
                 f"Contact signals are anatomically constrained to < 6s.")
        else:
            fire("Rule 3e: Very long duration (> 20s)",
                 {BehavioralClass.BROADCAST: 6.0, BehavioralClass.NAVIGATE: -2.0},
                 f"Duration {dur:.2f}s > 20s → broadcast song. "
                 f"Navigation pulses are never this long.")

        # ── RULE 4 — Urgency index ────────────────────────────────────────────
        if urg < 0.10:
            fire("Rule 4a: Very low urgency (< 0.10)",
                 {BehavioralClass.BROADCAST: 4.0, BehavioralClass.NAVIGATE: 2.0},
                 f"Urgency {urg:.2f} → sustained, non-alarm signal. "
                 f"Consistent with broadcast song or long-range navigation.")
        elif urg < 0.30:
            fire("Rule 4b: Low-moderate urgency (0.10–0.30)",
                 {BehavioralClass.CONTACT: 2.0, BehavioralClass.BROADCAST: 1.0},
                 f"Urgency {urg:.2f} → relaxed social context. "
                 f"Typical of contact maintenance and broadcast introduction.")
        elif urg < 0.55:
            fire("Rule 4c: Moderate urgency (0.30–0.55)",
                 {BehavioralClass.CONTACT: 3.0, BehavioralClass.FORAGE: 1.0},
                 f"Urgency {urg:.2f} → active coordination signal. "
                 f"Contact and foraging synchronization range.")
        elif urg < 0.75:
            fire("Rule 4d: High urgency (0.55–0.75)",
                 {BehavioralClass.FORAGE: 3.0, BehavioralClass.DIVE: 2.0},
                 f"Urgency {urg:.2f} → active prey pursuit or dive coordination. "
                 f"Elevated urgency during foraging and submergence.")
        else:
            fire("Rule 4e: Very high urgency (> 0.75)",
                 {BehavioralClass.FORAGE: 4.0, BehavioralClass.DIVE: 3.0,
                  BehavioralClass.CONTACT: -1.0},
                 f"Urgency {urg:.2f} → alarm or intense foraging. "
                 f"Broadcast and sustained contact signals are low-urgency by constraint.")

        # ── RULE 5 — IPI gate ─────────────────────────────────────────────────
        if ipi is not None:
            if ipi < 55:
                fire("Rule 5a: Very short IPI (< 55ms)",
                     {BehavioralClass.FORAGE: 5.0},
                     f"IPI {ipi:.0f}ms < 55ms → echolocation click train. "
                     f"No behavioral class produces social signals at this IPI.")
            elif ipi < 400:
                fire("Rule 5b: Short IPI (55–400ms) — social coda range",
                     {BehavioralClass.CONTACT: 3.0, BehavioralClass.FORAGE: 2.0},
                     f"IPI {ipi:.0f}ms → social coda or echolocation depending on frequency. "
                     f"Fix A handles disambiguation at pf > 30kHz.")
            elif ipi < 2_000:
                fire("Rule 5c: Medium IPI (400ms–2s)",
                     {BehavioralClass.CONTACT: 2.0, BehavioralClass.NAVIGATE: 2.0},
                     f"IPI {ipi:.0f}ms → contact call exchange or repetitive navigation signal.")
            elif ipi < 10_000:
                fire("Rule 5d: Long IPI (2–10s)",
                     {BehavioralClass.NAVIGATE: 4.0, BehavioralClass.BROADCAST: 2.0},
                     f"IPI {ipi:.0f}ms → navigation pulse train or broadcast phrase interval. "
                     f"Fix B handles disambiguation with duration + complexity.")
            else:
                fire("Rule 5e: Very long IPI (> 10s)",
                     {BehavioralClass.NAVIGATE: 3.0, BehavioralClass.BROADCAST: 3.0},
                     f"IPI {ipi:.0f}ms → long-period navigation or broadcast repetition.")
        else:
            fire("Rule 5f: Tonal signal (no IPI)",
                 {BehavioralClass.CONTACT: 1.0, BehavioralClass.BROADCAST: 1.0},
                 "No pulse structure detected → tonal signal. "
                 "Consistent with frequency-modulated contact calls or song units.")

        # ── RULE 6 — Composite override ───────────────────────────────────────
        # Override 1: Classic dive signal
        if fc == FreqContour.DESCENDING and dur < 3.0 and urg > 0.4:
            fire("Override 1: Classic dive initiation",
                 {BehavioralClass.DIVE: 5.0},
                 f"Descending contour + dur {dur:.1f}s < 3s + urgency {urg:.2f} > 0.4 → "
                 f"canonical dive initiation signal.")

        # Override 2: Navigation pulse — flat + low pf + low urgency + long IPI
        if (fc == FreqContour.FLAT and pf < 1_000 and urg < 0.25
                and ipi is not None and ipi > 5_000):
            fire("Override 2: Long-range navigation pulse",
                 {BehavioralClass.NAVIGATE: 5.0, BehavioralClass.BROADCAST: -2.0},
                 f"Flat + infrasonic + low urgency + IPI {ipi:.0f}ms > 5s → "
                 f"navigation pulse (fin whale 20Hz type).")

        # Override 3: Foraging echolocation — ultrasonic + very short + pulsed
        if pf > 20_000 and dur < 0.3 and ipi is not None and ipi < 200:
            fire("Override 3: Echolocation bout",
                 {BehavioralClass.FORAGE: 6.0, BehavioralClass.CONTACT: -4.0},
                 f"pf {pf:.0f} Hz + dur {dur:.2f}s < 0.3s + IPI {ipi:.0f}ms < 200ms → "
                 f"active echolocation. Consistent with toothed whale foraging.")

        # Override 4: Broadcast song — very complex + very long + very low urgency
        if fc == FreqContour.COMPLEX and dur > 12.0 and urg < 0.12:
            fire("Override 4: Extended broadcast song",
                 {BehavioralClass.BROADCAST: 6.0},
                 f"Complex + dur {dur:.1f}s > 12s + urgency {urg:.2f} < 0.12 → "
                 f"extended broadcast song unit (humpback / blue whale type).")

        # Override 5: Contact upcall — rising + low-mid + short + moderate urgency
        if (fc == FreqContour.RISING and 100 <= pf <= 2_000
                and dur < 2.5 and 0.25 <= urg <= 0.65):
            fire("Override 5: Contact upcall",
                 {BehavioralClass.CONTACT: 5.0},
                 f"Rising contour + pf {pf:.0f} Hz in 100–2000 + dur {dur:.1f}s < 2.5s + "
                 f"urgency {urg:.2f} → contact upcall (NARW type).")

        # Override 6: Broadband foraging burst
        if (fr[1] - fr[0] > 20_000 and urg > 0.6 and dur < 0.5):
            fire("Override 6: Broadband burst-pulse",
                 {BehavioralClass.FORAGE: 4.0},
                 f"Frequency range {fr[0]:.0f}–{fr[1]:.0f} Hz (span > 20kHz) + "
                 f"urgency {urg:.2f} + dur {dur:.2f}s → burst-pulse foraging signal.")

        # ── FINAL PREDICTION ──────────────────────────────────────────────────
        probabilities = _softmax(scores)
        sorted_probs = sorted(probabilities.items(), key=lambda x: x[1], reverse=True)
        predicted_class = sorted_probs[0][0]
        confidence = sorted_probs[0][1]
        top_two_margin = sorted_probs[0][1] - sorted_probs[1][1]

        # Boundary type assessment — low margin signals ambiguity
        boundary_type = BoundaryType.NONE
        if top_two_margin < 0.15:
            top_two = {sorted_probs[0][0], sorted_probs[1][0]}
            if top_two == {BehavioralClass.BROADCAST, BehavioralClass.NAVIGATE}:
                boundary_type = BoundaryType.BROADCAST_NAVIGATE
            elif top_two == {BehavioralClass.CONTACT, BehavioralClass.BROADCAST}:
                boundary_type = BoundaryType.CONTACT_BROADCAST
            else:
                boundary_type = BoundaryType.OTHER

        return CadenceResult(
            predicted_class = predicted_class,
            confidence      = confidence,
            class_scores    = {k.value: v for k, v in probabilities.items()},
            rule_trace      = trace,
            boundary_type   = boundary_type,
            top_two_margin  = top_two_margin,
        )

"""
context_layer.py
────────────────
Second-pass context classifier — Layer 2 of the CetaSignal pipeline.

Receives the CadenceResult from Layer 1 and injects environmental
context features to attempt resolution of boundary-type predictions.

One handler per hypothesis (H1–H4). H5 runs all handlers sequentially.
Each handler is a clean function — easy to ablate individually.

When a handler resolves the prediction, it records which channel
resolved it. This is the primary data for the ablation study.
"""

from __future__ import annotations
import math
from typing import Optional, List
from ingestion.specimen_schema import (
    AcousticFeatures, ContextRecord, CadenceResult, ContextResult,
    BehavioralClass, BoundaryType, SpatiotemporalFeatures,
    DepthFeatures, SequenceFeatures, PopulationFeatures, Season
)


# ─── SEASON LOOKUP ────────────────────────────────────────────────────────────

def _month_to_season(month: int) -> Season:
    if month in (12, 1, 2):  return Season.WINTER
    if month in (3, 4, 5):   return Season.SPRING
    if month in (6, 7, 8):   return Season.SUMMER
    return Season.AUTUMN


# ─── KNOWN BROADCAST RANGES ───────────────────────────────────────────────────
# Species broadcasting seasonally — (lat_min, lat_max, lon_min, lon_max, months)
# Used by H1 to gate BROADCAST/NAVIGATE boundary.

BROADCAST_ZONES = [
    # Humpback — North Atlantic breeding grounds
    {"label": "humpback_NA_breeding", "lat": (10, 25), "lon": (-80, -60), "months": {1,2,3,4,12}},
    # Humpback — North Pacific breeding grounds
    {"label": "humpback_NP_breeding", "lat": (18, 28), "lon": (-160, -145), "months": {1,2,3,4,12}},
    # Blue whale — Northeast Pacific feeding/song
    {"label": "blue_NE_pacific", "lat": (30, 50), "lon": (-140, -115), "months": {6,7,8,9,10}},
    # Fin whale — North Atlantic winter song
    {"label": "fin_NA_winter", "lat": (25, 50), "lon": (-75, -20), "months": {11,12,1,2,3}},
    # Omura's whale — Madagascar
    {"label": "omura_madagascar", "lat": (-18, -10), "lon": (42, 50), "months": {6,7,8,9,10,11}},
    # Antarctic blue whale — Southern Ocean
    {"label": "blue_antarctic", "lat": (-70, -45), "lon": (-180, 180), "months": {1,2,3,4,11,12}},
]

def _in_broadcast_zone(st: SpatiotemporalFeatures) -> Optional[str]:
    """Returns zone label if coordinates + month match a known broadcast zone."""
    for zone in BROADCAST_ZONES:
        lat_ok = zone["lat"][0] <= st.latitude  <= zone["lat"][1]
        lon_ok = zone["lon"][0] <= st.longitude <= zone["lon"][1]
        month_ok = st.month in zone["months"]
        if lat_ok and lon_ok and month_ok:
            return zone["label"]
    return None


# ─── POPULATION LOOKUP ────────────────────────────────────────────────────────

POPULATION_RANGES = {
    # (lat_min, lat_max, lon_min, lon_max) → population_id
    ((40, 50, -70, -50), (10, 12)): "NARW_WNA",            # NARW winter
    ((40, 50, -70, -50), (5, 9)):   "NARW_WNA_summer",
    ((47, 52, -130, -120), None):   "SRKW_combined",
    ((60, 70, -30, 30), None):      "NARW_NA_north",
    ((-75, -45, -180, 180), None):  "BLUE_ANTARCTIC",
    ((-18, -10, 42, 50), None):     "OMURA_MADAGASCAR",
}


# ─── H1 — SPATIOTEMPORAL ─────────────────────────────────────────────────────

def h1_spatiotemporal(
    cadence: CadenceResult,
    context: ContextRecord,
) -> Optional[tuple[BehavioralClass, float, str]]:
    """
    H1: Use GPS coordinates + calendar month to gate BROADCAST/NAVIGATE boundary.

    Returns (refined_class, confidence_boost, rationale) or None if not applicable.
    """
    if cadence.boundary_type != BoundaryType.BROADCAST_NAVIGATE:
        return None
    st = context.spatiotemporal
    if st is None:
        return None

    zone = _in_broadcast_zone(st)
    season = _month_to_season(st.month)

    if zone:
        # Within a known broadcast zone at the right time → BROADCAST
        confidence = min(cadence.confidence + 0.25, 0.97)
        rationale = (
            f"H1: Recording within known broadcast zone '{zone}' "
            f"(lat={st.latitude:.1f}, lon={st.longitude:.1f}, month={st.month}). "
            f"Season: {season.value}. Spatial-temporal context strongly supports BROADCAST."
        )
        return (BehavioralClass.BROADCAST, confidence, rationale)

    # Outside broadcast zones → lean NAVIGATE
    # But only if winter/autumn at high latitudes (migration context)
    if season in (Season.WINTER, Season.AUTUMN) and abs(st.latitude) > 40:
        confidence = min(cadence.confidence + 0.15, 0.92)
        rationale = (
            f"H1: High latitude ({st.latitude:.1f}°) in {season.value} — "
            f"migration period. Context supports NAVIGATE over BROADCAST."
        )
        return (BehavioralClass.NAVIGATE, confidence, rationale)

    return None   # Spatiotemporal context insufficient to resolve


# ─── H2 — DEPTH PROFILE ──────────────────────────────────────────────────────

def h2_depth(
    cadence: CadenceResult,
    context: ContextRecord,
) -> Optional[tuple[BehavioralClass, float, str]]:
    """
    H2: Use DTAG depth profile at signal onset to resolve BROADCAST/NAVIGATE.

    Key discriminator: dD/dt (depth rate of change in 60s preceding onset).
    - Sustained directional movement (consistent dD/dt ≈ 0, speed > 0) → NAVIGATE
    - Station-keeping (dD/dt ≈ 0, low speed variance) → BROADCAST
    - Active descent (dD/dt > 0) → check for DIVE override
    """
    if cadence.boundary_type != BoundaryType.BROADCAST_NAVIGATE:
        return None
    depth = context.depth
    if depth is None or not depth.dtag_available:
        return None

    d_rate = depth.depth_rate_m_per_s
    inferred = depth.inferred_state

    if d_rate is not None:
        # Actively descending → likely dive-associated, not broadcast
        if d_rate > 0.5:
            confidence = min(cadence.confidence + 0.20, 0.95)
            return (BehavioralClass.NAVIGATE,
                    confidence,
                    f"H2: Depth rate {d_rate:.2f} m/s (descending) at signal onset. "
                    f"Active descent inconsistent with broadcast song station-keeping.")

        # Near-zero depth rate → station-keeping → broadcast
        if abs(d_rate) < 0.1 and depth.depth_std_60s is not None and depth.depth_std_60s < 2.0:
            confidence = min(cadence.confidence + 0.22, 0.95)
            return (BehavioralClass.BROADCAST,
                    confidence,
                    f"H2: Depth rate {d_rate:.3f} m/s (station-keeping), "
                    f"depth std {depth.depth_std_60s:.2f}m in preceding 60s. "
                    f"Station-keeping behavioral state supports BROADCAST.")

    if inferred == "station_keeping":
        confidence = min(cadence.confidence + 0.18, 0.93)
        return (BehavioralClass.BROADCAST, confidence,
                f"H2: Inferred behavioral state 'station_keeping' from depth profile → BROADCAST.")

    return None


# ─── H3 — SEQUENCE CONTEXT ───────────────────────────────────────────────────

def h3_sequence(
    cadence: CadenceResult,
    context: ContextRecord,
) -> Optional[tuple[BehavioralClass, float, str]]:
    """
    H3: Use 90-second preceding call window to resolve CONTACT/BROADCAST.

    Key discriminators:
    - High inter-call interval variance + rising urgency gradient → CONTACT exchange
    - Low ICI variance + monotonic urgency → BROADCAST sequence
    - Response pattern index > 0.6 → CONTACT (call-response structure)
    """
    if cadence.boundary_type != BoundaryType.CONTACT_BROADCAST:
        return None
    seq = context.sequence
    if seq is None or not seq.window_available:
        return None

    rpi = seq.response_pattern_index
    urg_grad = seq.urgency_gradient
    ici_var = seq.inter_call_interval_var

    # Strong call-response pattern → CONTACT
    if rpi is not None and rpi > 0.6:
        confidence = min(cadence.confidence + 0.28, 0.96)
        return (BehavioralClass.CONTACT,
                confidence,
                f"H3: Response pattern index {rpi:.2f} > 0.6 in 90s preceding window. "
                f"Call-response exchange structure → CONTACT.")

    # Rising urgency gradient with high ICI variance → CONTACT escalation
    if (urg_grad is not None and urg_grad > 0.05
            and ici_var is not None and ici_var > 1_000):
        confidence = min(cadence.confidence + 0.20, 0.93)
        return (BehavioralClass.CONTACT,
                confidence,
                f"H3: Rising urgency gradient ({urg_grad:.3f}/call) + "
                f"high ICI variance ({ici_var:.0f}ms²) → contact escalation sequence.")

    # Monotonic, low-variance sequence → BROADCAST
    if (urg_grad is not None and abs(urg_grad) < 0.02
            and ici_var is not None and ici_var < 500
            and seq.n_calls_preceding >= 3):
        confidence = min(cadence.confidence + 0.22, 0.94)
        return (BehavioralClass.BROADCAST,
                confidence,
                f"H3: Monotonic urgency (gradient {urg_grad:.4f}), "
                f"low ICI variance ({ici_var:.0f}ms²), {seq.n_calls_preceding} preceding calls → "
                f"broadcast song sequence.")

    return None


# ─── H4 — POPULATION IDENTITY ────────────────────────────────────────────────

def h4_population(
    cadence: CadenceResult,
    context: ContextRecord,
) -> Optional[tuple[BehavioralClass, float, str]]:
    """
    H4: Use population identity to resolve dialect-driven ambiguity.

    Some populations have documented call forms that differ from
    population-general expectations. Conditioning on population
    can resolve cases where the generic classifier is uncertain.
    """
    pop = context.population
    if pop is None or pop.population_id is None:
        return None

    # Only apply to boundary cases — population identity is not useful
    # for clear predictions (would just add noise)
    if cadence.boundary_type == BoundaryType.NONE:
        return None

    pid = pop.population_id

    # NARW — contact upcalls are exclusively CONTACT; no broadcast overlap
    if "NARW" in pid:
        if cadence.boundary_type == BoundaryType.CONTACT_BROADCAST:
            confidence = min(cadence.confidence + 0.30, 0.97)
            return (BehavioralClass.CONTACT,
                    confidence,
                    f"H4: Population '{pid}' is NARW. NARW contact upcalls are exclusively "
                    f"CONTACT class — no broadcast overlap documented in this population.")

    # SRKW — discrete calls at boundary are CONTACT (pod identity)
    if "SRKW" in pid:
        if cadence.boundary_type in (BoundaryType.CONTACT_BROADCAST, BoundaryType.BROADCAST_NAVIGATE):
            confidence = min(cadence.confidence + 0.25, 0.95)
            return (BehavioralClass.CONTACT,
                    confidence,
                    f"H4: Population '{pid}' is SRKW. SRKW discrete calls at ambiguous "
                    f"boundaries are CONTACT — pod cohesion function documented.")

    # Antarctic blue / Omura's — boundary cases lean BROADCAST
    if any(x in pid for x in ("ANTARCTIC", "OMURA")):
        if cadence.boundary_type == BoundaryType.BROADCAST_NAVIGATE:
            confidence = min(cadence.confidence + 0.20, 0.94)
            return (BehavioralClass.BROADCAST,
                    confidence,
                    f"H4: Population '{pid}'. This population's boundary signals are "
                    f"predominantly broadcast song based on source dataset annotation.")

    return None


# ─── H5 — COMBINED (ABLATION ORCHESTRATOR) ───────────────────────────────────

def h5_combined(
    cadence: CadenceResult,
    context: ContextRecord,
    enabled_channels: Optional[List[str]] = None,
) -> ContextResult:
    """
    H5: Run all available context channels sequentially.
    First channel to resolve the boundary wins.

    enabled_channels: subset of ["h1","h2","h3","h4"] for ablation study.
    Default: all channels attempted in order.
    """
    if enabled_channels is None:
        enabled_channels = ["h1", "h2", "h3", "h4"]

    available = context.available_channels()
    channels_used = []

    # Start with cadence prediction
    current_class = cadence.predicted_class
    current_confidence = cadence.confidence
    resolved_by = None

    handlers = {
        "h1": h1_spatiotemporal,
        "h2": h2_depth,
        "h3": h3_sequence,
        "h4": h4_population,
    }

    for channel_key in enabled_channels:
        channel_label = f"h{channel_key[-1]}_spatiotemporal" if channel_key == "h1" else \
                        f"h{channel_key[-1]}_depth"          if channel_key == "h2" else \
                        f"h{channel_key[-1]}_sequence"       if channel_key == "h3" else \
                        f"h{channel_key[-1]}_population"

        if channel_key not in handlers:
            continue

        result = handlers[channel_key](cadence, context)
        if result is not None:
            refined_class, refined_conf, rationale = result
            channels_used.append(channel_key)

            if refined_class != current_class:
                # Class changed — this channel resolved the boundary
                current_class = refined_class
                current_confidence = refined_conf
                resolved_by = channel_key
                break   # Stop at first resolution
            else:
                # Same class, confidence boosted
                current_class = refined_class
                current_confidence = refined_conf
                channels_used.append(channel_key)

    delta = current_confidence - cadence.confidence

    return ContextResult(
        refined_class      = current_class,
        context_confidence = current_confidence,
        resolved_by        = resolved_by,
        channels_used      = channels_used,
        channels_available = available,
        delta_confidence   = delta,
    )

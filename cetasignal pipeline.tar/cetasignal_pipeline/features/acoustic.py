"""
acoustic.py
───────────
Extracts AcousticFeatures from a WAV/FLAC audio array.

Uses librosa for spectral analysis. Produces the exact feature set
consumed by CadenceClassifier:
  - peak_frequency_hz
  - duration_s
  - freq_contour
  - urgency_index
  - frequency_range_hz
  - inter_pulse_interval_ms (None for tonal signals)

All values are validated against physical bounds before returning.
Out-of-range values raise ValueError with a diagnostic message.
"""

from __future__ import annotations
import numpy as np
from typing import Optional, Tuple
from ingestion.specimen_schema import AcousticFeatures, FreqContour

try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False


# ─── PHYSICAL BOUNDS ──────────────────────────────────────────────────────────
# All documented cetacean vocalizations fall within these ranges.
# Violations indicate bad audio or a non-cetacean signal.

FREQ_MIN_HZ   =    10    # infrasonic limit (blue whale)
FREQ_MAX_HZ   = 160_000  # ultrasonic limit (porpoise echolocation)
DURATION_MIN  =   0.05   # 50ms minimum
DURATION_MAX  = 120.0    # 120s maximum (humpback song unit)
URGENCY_MIN   =   0.0
URGENCY_MAX   =   1.0
IPI_MIN_MS    =   5.0    # 5ms minimum IPI
IPI_MAX_MS    = 60_000   # 60s maximum IPI (broadcast phrase interval)


# ─── CONTOUR CLASSIFIER ───────────────────────────────────────────────────────

def _classify_contour(
    freqs_over_time: np.ndarray,
    times: np.ndarray,
    threshold_hz: float = 50.0,
) -> FreqContour:
    """
    Classify the frequency trajectory of a call.

    Uses linear regression slope over the dominant frequency track.
    Complex calls have high residual variance relative to slope.
    """
    if len(freqs_over_time) < 4:
        return FreqContour.FLAT

    # Filter out zero/silence frames
    valid = freqs_over_time > 0
    if valid.sum() < 4:
        return FreqContour.FLAT

    f = freqs_over_time[valid]
    t = np.linspace(0, 1, len(f))

    # Linear fit
    slope, intercept = np.polyfit(t, f, 1)
    residuals = f - (slope * t + intercept)
    residual_std = np.std(residuals)

    # Complexity: residual variance relative to frequency range
    freq_range = f.max() - f.min()
    complexity_ratio = residual_std / max(freq_range, 1.0)

    if complexity_ratio > 0.25:
        return FreqContour.COMPLEX

    slope_hz = slope  # slope in Hz over the call duration

    if slope_hz > threshold_hz:
        return FreqContour.RISING
    elif slope_hz < -threshold_hz:
        return FreqContour.DESCENDING
    else:
        return FreqContour.FLAT


# ─── URGENCY INDEX ────────────────────────────────────────────────────────────

def _compute_urgency(
    y: np.ndarray,
    sr: int,
    duration_s: float,
) -> float:
    """
    Urgency index — composite of:
      - Amplitude envelope rise rate (fast attack = higher urgency)
      - Spectral centroid variance (instability = higher urgency)
      - Call rate proxy (short duration → higher potential urgency)

    Returns value in [0, 1]. Calibrated against documented species values.
    """
    # Amplitude envelope
    envelope = np.abs(librosa.effects.preemphasis(y)) if LIBROSA_AVAILABLE else np.abs(y)
    env_smooth = np.convolve(envelope, np.ones(sr // 100) / (sr // 100), mode='same')

    # Rise rate — time to 90% peak relative to duration
    peak = env_smooth.max()
    if peak == 0:
        return 0.0
    threshold = 0.9 * peak
    rise_samples = np.argmax(env_smooth >= threshold)
    rise_ratio = rise_samples / max(len(env_smooth), 1)
    urgency_rise = 1.0 - rise_ratio   # fast rise = high urgency

    # Spectral centroid variance (requires librosa)
    urgency_spectral = 0.5  # default if librosa unavailable
    if LIBROSA_AVAILABLE:
        centroid = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
        centroid_norm = centroid / max(centroid.max(), 1.0)
        urgency_spectral = float(np.std(centroid_norm)) * 3.0  # scale to ~[0,1]
        urgency_spectral = min(urgency_spectral, 1.0)

    # Duration proxy — shorter calls tend toward higher urgency in contact/forage
    urgency_duration = max(0.0, 1.0 - (duration_s / 30.0))

    # Weighted composite
    urgency = (0.4 * urgency_rise) + (0.4 * urgency_spectral) + (0.2 * urgency_duration)
    return float(np.clip(urgency, 0.0, 1.0))


# ─── IPI DETECTOR ─────────────────────────────────────────────────────────────

def _detect_ipi(
    y: np.ndarray,
    sr: int,
    min_ipi_ms: float = 5.0,
    energy_threshold: float = 0.05,
) -> Optional[float]:
    """
    Detect inter-pulse interval in pulsed signals.

    Uses onset detection to find pulse timestamps, then computes
    median inter-pulse interval. Returns None for tonal (non-pulsed)
    signals where no clear pulse structure is detected.
    """
    if not LIBROSA_AVAILABLE:
        return None

    # Onset detection
    onset_frames = librosa.onset.onset_detect(
        y=y, sr=sr, units='time',
        delta=0.05, wait=int(min_ipi_ms * sr / 1000),
    )

    if len(onset_frames) < 2:
        return None   # tonal or single-pulse — no IPI

    # Filter onsets by energy (remove spurious detections)
    hop = 512
    onset_strength = librosa.onset.onset_strength(y=y, sr=sr)
    frame_indices = librosa.time_to_frames(onset_frames, sr=sr, hop_length=hop)
    frame_indices = np.clip(frame_indices, 0, len(onset_strength) - 1)
    strong = onset_strength[frame_indices] > (energy_threshold * onset_strength.max())
    onset_times = onset_frames[strong]

    if len(onset_times) < 2:
        return None

    intervals_ms = np.diff(onset_times) * 1000.0
    median_ipi = float(np.median(intervals_ms))

    if median_ipi < IPI_MIN_MS or median_ipi > IPI_MAX_MS:
        return None

    return median_ipi


# ─── MAIN EXTRACTOR ───────────────────────────────────────────────────────────

class AcousticExtractor:
    """
    Extracts AcousticFeatures from a raw audio array.

    Usage:
        extractor = AcousticExtractor(sample_rate=44100)
        features = extractor.extract(audio_array)
    """

    def __init__(self, sample_rate: int = 44100):
        if not LIBROSA_AVAILABLE:
            raise ImportError(
                "librosa is required for acoustic feature extraction. "
                "Install with: pip install librosa --break-system-packages"
            )
        self.sr = sample_rate

    def extract(self, y: np.ndarray) -> AcousticFeatures:
        """
        Full feature extraction pipeline.

        Args:
            y: Audio array, mono, float32, normalized to [-1, 1]

        Returns:
            AcousticFeatures with all fields populated

        Raises:
            ValueError: If audio is silent, too short, or features are out of range
        """
        if len(y) < self.sr * 0.05:
            raise ValueError(f"Audio too short: {len(y)/self.sr:.3f}s (min 50ms)")

        if np.max(np.abs(y)) < 0.001:
            raise ValueError("Audio appears to be silent (max amplitude < 0.001)")

        # Duration
        duration_s = len(y) / self.sr

        # Spectrogram for frequency analysis
        n_fft = min(2048, len(y) // 4)
        hop_length = n_fft // 4
        stft = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=hop_length))
        freqs = librosa.fft_frequencies(sr=self.sr, n_fft=n_fft)

        # Peak frequency — weighted centroid of spectral peak band
        mean_spectrum = stft.mean(axis=1)
        peak_bin = int(np.argmax(mean_spectrum))
        peak_frequency_hz = float(freqs[peak_bin])

        # Frequency range — bins where energy > 10% of peak
        threshold = mean_spectrum.max() * 0.1
        active_bins = freqs[mean_spectrum > threshold]
        if len(active_bins) > 0:
            freq_range = (float(active_bins.min()), float(active_bins.max()))
        else:
            freq_range = (peak_frequency_hz * 0.8, peak_frequency_hz * 1.2)

        # Dominant frequency track over time (for contour)
        dominant_freqs = freqs[np.argmax(stft, axis=0)]

        # Contour
        times = librosa.frames_to_time(
            np.arange(stft.shape[1]), sr=self.sr, hop_length=hop_length
        )
        freq_contour = _classify_contour(dominant_freqs, times)

        # IPI — attempt pulse detection
        ipi_ms = _detect_ipi(y, self.sr)

        # If IPI detected, signal is pulsed — override contour
        if ipi_ms is not None and freq_contour == FreqContour.FLAT:
            freq_contour = FreqContour.PULSED

        # Urgency
        urgency_index = _compute_urgency(y, self.sr, duration_s)

        # Validate
        self._validate(peak_frequency_hz, duration_s, urgency_index)

        return AcousticFeatures(
            peak_frequency_hz       = peak_frequency_hz,
            duration_s              = duration_s,
            freq_contour            = freq_contour,
            urgency_index           = urgency_index,
            frequency_range_hz      = freq_range,
            inter_pulse_interval_ms = ipi_ms,
        )

    def _validate(self, pf: float, dur: float, urg: float) -> None:
        if not (FREQ_MIN_HZ <= pf <= FREQ_MAX_HZ):
            raise ValueError(f"Peak frequency {pf:.1f} Hz outside cetacean range [{FREQ_MIN_HZ}, {FREQ_MAX_HZ}]")
        if not (DURATION_MIN <= dur <= DURATION_MAX):
            raise ValueError(f"Duration {dur:.2f}s outside range [{DURATION_MIN}, {DURATION_MAX}]")
        if not (URGENCY_MIN <= urg <= URGENCY_MAX):
            raise ValueError(f"Urgency index {urg:.3f} outside [0, 1]")

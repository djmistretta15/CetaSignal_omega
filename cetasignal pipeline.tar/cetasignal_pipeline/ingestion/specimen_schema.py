"""
specimen_schema.py
──────────────────
Canonical data models for the CetaSignal context layer pipeline.

All data flowing through the pipeline is typed via dataclasses.
No dicts passed between modules — always use these schemas.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
from enum import Enum


# ─── ENUMS ────────────────────────────────────────────────────────────────────

class BehavioralClass(str, Enum):
    CONTACT   = "CONTACT"
    DIVE      = "DIVE"
    FORAGE    = "FORAGE"
    NAVIGATE  = "NAVIGATE"
    BROADCAST = "BROADCAST"
    UNKNOWN   = "UNKNOWN"


class FreqContour(str, Enum):
    RISING     = "rising"
    DESCENDING = "descending"
    FLAT       = "flat"
    COMPLEX    = "complex"
    PULSED     = "pulsed"


class BoundaryType(str, Enum):
    BROADCAST_NAVIGATE = "BROADCAST_NAVIGATE"
    CONTACT_BROADCAST  = "CONTACT_BROADCAST"
    OTHER              = "OTHER"
    NONE               = "NONE"   # not an error


class Season(str, Enum):
    WINTER = "winter"   # Dec–Feb
    SPRING = "spring"   # Mar–May
    SUMMER = "summer"   # Jun–Aug
    AUTUMN = "autumn"   # Sep–Nov


# ─── ACOUSTIC FEATURES ────────────────────────────────────────────────────────

@dataclass
class AcousticFeatures:
    """
    Core cadence features — direct inputs to CadenceClassifier.
    These are the only features used by Layer 1 (cadence engine).
    """
    peak_frequency_hz:       float
    duration_s:              float
    freq_contour:            FreqContour
    urgency_index:           float                  # 0.0–1.0
    frequency_range_hz:      Tuple[float, float]
    inter_pulse_interval_ms: Optional[float] = None # None = tonal signal

    def to_dict(self) -> dict:
        return {
            "peakFrequency_hz":       self.peak_frequency_hz,
            "duration_s":             self.duration_s,
            "freqContour":            self.freq_contour.value,
            "urgencyIndex":           self.urgency_index,
            "frequencyRange_hz":      list(self.frequency_range_hz),
            "interPulseInterval_ms":  self.inter_pulse_interval_ms,
        }


# ─── CONTEXT FEATURES ─────────────────────────────────────────────────────────

@dataclass
class SpatiotemporalFeatures:
    """H1 — GPS coordinates + calendar encoding."""
    latitude:   float              # decimal degrees, positive = N
    longitude:  float              # decimal degrees, positive = E
    year:       int
    month:      int                # 1–12
    day:        Optional[int]

    # Derived
    season:     Optional[Season] = None
    season_sin: Optional[float]  = None  # cyclical month encoding
    season_cos: Optional[float]  = None


@dataclass
class DepthFeatures:
    """H2 — DTAG depth profile at signal onset."""
    depth_at_onset_m:       float
    depth_60s_before_m:     Optional[float]
    depth_rate_m_per_s:     Optional[float]   # dD/dt — positive = descending
    depth_std_60s:          Optional[float]   # variance in preceding window
    inferred_state:         Optional[str]     # "descending", "ascending", "station_keeping"
    dtag_available:         bool = False


@dataclass
class SequenceFeatures:
    """H3 — 90s preceding call window analysis."""
    n_calls_preceding:         int
    inter_call_interval_mean:  Optional[float]  # ms
    inter_call_interval_var:   Optional[float]  # ms²
    urgency_gradient:          Optional[float]  # slope of urgency over window
    response_pattern_index:    Optional[float]  # 0=no pattern, 1=strong call-response
    window_available:          bool = False


@dataclass
class PopulationFeatures:
    """H4 — population identity derived from location + year."""
    population_id:    Optional[str]   # e.g. "NARW_WNA", "SRKW_J_POD"
    population_range: Optional[str]   # geographic label
    dialect_group:    Optional[str]   # for species with documented dialects
    derived_from:     str = "location_year"  # how population was assigned


# ─── CONTEXT RECORD ───────────────────────────────────────────────────────────

@dataclass
class ContextRecord:
    """
    All available environmental context for a single specimen.
    Fields are Optional — populated only when data is available.
    The pipeline proceeds with whatever subset is present.
    """
    spatiotemporal: Optional[SpatiotemporalFeatures] = None
    depth:          Optional[DepthFeatures]          = None
    sequence:       Optional[SequenceFeatures]       = None
    population:     Optional[PopulationFeatures]     = None

    def available_channels(self) -> List[str]:
        channels = []
        if self.spatiotemporal: channels.append("h1_spatiotemporal")
        if self.depth and self.depth.dtag_available: channels.append("h2_depth")
        if self.sequence and self.sequence.window_available: channels.append("h3_sequence")
        if self.population: channels.append("h4_population")
        return channels


# ─── SPECIMEN ─────────────────────────────────────────────────────────────────

@dataclass
class Specimen:
    """A single catalogued vocalization with full provenance."""
    catalog_id:       str
    species:          str
    common_name:      str
    call_type:        str
    source_dataset:   str
    audio_path:       Optional[str]
    acoustic:         AcousticFeatures
    context:          ContextRecord
    ground_truth:     Optional[BehavioralClass] = None  # held out during classification
    notes:            str = ""


# ─── CLASSIFICATION RESULTS ───────────────────────────────────────────────────

@dataclass
class RuleTrace:
    """A single fired rule in the cadence engine evidence trail."""
    step:         int
    rule_name:    str
    contribution: float   # score delta
    rationale:    str
    fired:        bool


@dataclass
class CadenceResult:
    """Output of Layer 1 — the cadence-only classifier."""
    predicted_class:  BehavioralClass
    confidence:       float               # 0.0–1.0
    class_scores:     Dict[str, float]    # score per class
    rule_trace:       List[RuleTrace]
    boundary_type:    BoundaryType        # NONE if not an error boundary
    top_two_margin:   float               # confidence gap to second-best class


@dataclass
class ContextResult:
    """Output of Layer 2 — the context-layer refinement."""
    refined_class:      BehavioralClass
    context_confidence: float
    resolved_by:        Optional[str]     # which channel resolved ambiguity
    channels_used:      List[str]
    channels_available: List[str]
    delta_confidence:   float             # improvement over cadence-only


@dataclass
class ClassificationResult:
    """
    Full pipeline output for a single specimen.
    Serializable to JSON for logging and error tracking.
    """
    catalog_id:       str
    species:          str
    cadence:          CadenceResult
    context:          Optional[ContextResult]
    ground_truth:     Optional[BehavioralClass]
    is_error:         bool
    boundary_type:    BoundaryType
    resolved:         bool    # True if context layer corrected a cadence error

    def to_dict(self) -> dict:
        return {
            "catalog_id":    self.catalog_id,
            "species":       self.species,
            "predicted":     self.cadence.predicted_class.value,
            "refined":       self.context.refined_class.value if self.context else None,
            "ground_truth":  self.ground_truth.value if self.ground_truth else None,
            "confidence":    self.cadence.confidence,
            "ctx_confidence": self.context.context_confidence if self.context else None,
            "is_error":      self.is_error,
            "boundary":      self.boundary_type.value,
            "resolved":      self.resolved,
            "resolved_by":   self.context.resolved_by if self.context else None,
            "channels_used": self.context.channels_used if self.context else [],
        }

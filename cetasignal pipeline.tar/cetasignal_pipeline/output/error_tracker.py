"""
error_tracker.py
────────────────
Tracks classification errors across a validation run.
Supports boundary error isolation for the context layer experiment.

Records every prediction with ground truth and logs:
  - total accuracy
  - per-class metrics (precision, recall, F1)
  - boundary error distribution
  - context layer resolution rate (H1–H5 ablation results)

Output: structured JSON log + summary report.
"""

from __future__ import annotations
import json
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional
from ingestion.specimen_schema import (
    BehavioralClass, BoundaryType, ClassificationResult
)


@dataclass
class BoundaryErrorRecord:
    catalog_id:    str
    species:       str
    predicted:     str
    ground_truth:  str
    boundary_type: str
    confidence:    float
    margin:        float
    resolved:      bool
    resolved_by:   Optional[str]
    channels_available: List[str]


@dataclass
class AblationResult:
    """Results for one channel combination in the ablation study."""
    channels_enabled:  List[str]
    total_errors:      int
    boundary_errors:   int
    resolved_count:    int
    resolution_rate:   float    # resolved / boundary_errors
    accuracy:          float    # (total - errors) / total


@dataclass
class ErrorReport:
    total_specimens:       int
    total_correct:         int
    total_errors:          int
    accuracy:              float
    kappa:                 float
    boundary_errors:       Dict[str, int]    # by BoundaryType
    per_class_metrics:     Dict[str, dict]   # precision, recall, F1 per class
    boundary_records:      List[BoundaryErrorRecord]
    ablation_results:      List[AblationResult]


class ErrorTracker:
    """
    Accumulates ClassificationResults and computes error analysis.

    Usage:
        tracker = ErrorTracker()
        for result in results:
            tracker.add(result)
        report = tracker.report()
        tracker.save("errors.json")
    """

    def __init__(self):
        self._results: List[ClassificationResult] = []

    def add(self, result: ClassificationResult) -> None:
        self._results.append(result)

    def report(self) -> ErrorReport:
        results = self._results
        n = len(results)
        if n == 0:
            raise ValueError("No results recorded.")

        classes = [c for c in BehavioralClass if c != BehavioralClass.UNKNOWN]

        # Confusion matrix
        confusion = defaultdict(lambda: defaultdict(int))
        for r in results:
            gt  = r.ground_truth or BehavioralClass.UNKNOWN
            pred = r.context.refined_class if r.context else r.cadence.predicted_class
            confusion[gt][pred] += 1

        # Per-class metrics
        per_class = {}
        for cls in classes:
            tp = confusion[cls][cls]
            fp = sum(confusion[c][cls] for c in classes if c != cls)
            fn = sum(confusion[cls][c] for c in classes if c != cls)
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1        = (2 * precision * recall / (precision + recall)
                         if (precision + recall) > 0 else 0.0)
            per_class[cls.value] = {
                "precision": round(precision, 4),
                "recall":    round(recall, 4),
                "f1":        round(f1, 4),
                "tp": tp, "fp": fp, "fn": fn,
            }

        # Overall accuracy
        correct = sum(1 for r in results if not r.is_error)
        accuracy = correct / n

        # Cohen's kappa
        kappa = self._kappa(confusion, classes, n)

        # Boundary error distribution
        boundary_counts = defaultdict(int)
        boundary_records = []
        for r in results:
            if r.is_error:
                boundary_counts[r.boundary_type.value] += 1
                boundary_records.append(BoundaryErrorRecord(
                    catalog_id    = r.catalog_id,
                    species       = r.species,
                    predicted     = r.cadence.predicted_class.value,
                    ground_truth  = r.ground_truth.value if r.ground_truth else "UNKNOWN",
                    boundary_type = r.boundary_type.value,
                    confidence    = round(r.cadence.confidence, 4),
                    margin        = round(r.cadence.top_two_margin, 4),
                    resolved      = r.resolved,
                    resolved_by   = r.context.resolved_by if r.context else None,
                    channels_available = r.context.channels_available if r.context else [],
                ))

        # Ablation results
        ablation = self._ablation_analysis(results)

        return ErrorReport(
            total_specimens   = n,
            total_correct     = correct,
            total_errors      = n - correct,
            accuracy          = round(accuracy, 5),
            kappa             = round(kappa, 4),
            boundary_errors   = dict(boundary_counts),
            per_class_metrics = per_class,
            boundary_records  = boundary_records,
            ablation_results  = ablation,
        )

    def save(self, path: str) -> None:
        report = self.report()
        out = {
            "summary": {
                "total":    report.total_specimens,
                "correct":  report.total_correct,
                "errors":   report.total_errors,
                "accuracy": report.accuracy,
                "kappa":    report.kappa,
            },
            "boundary_errors":   report.boundary_errors,
            "per_class_metrics": report.per_class_metrics,
            "boundary_records":  [
                {k: v for k, v in vars(r).items()} for r in report.boundary_records
            ],
            "ablation_results":  [
                {k: v for k, v in vars(a).items()} for a in report.ablation_results
            ],
        }
        with open(path, "w") as f:
            json.dump(out, f, indent=2)
        print(f"Error report saved to {path}")
        print(f"  Total: {report.total_specimens} | Errors: {report.total_errors} | "
              f"Accuracy: {report.accuracy:.1%} | κ={report.kappa:.3f}")

    def print_summary(self) -> None:
        report = self.report()
        print(f"\n{'='*60}")
        print(f"  CETASIGNAL CLASSIFICATION REPORT")
        print(f"{'='*60}")
        print(f"  Specimens:  {report.total_specimens}")
        print(f"  Correct:    {report.total_correct}")
        print(f"  Errors:     {report.total_errors}")
        print(f"  Accuracy:   {report.accuracy:.2%}")
        print(f"  Cohen's κ:  {report.kappa:.4f}")
        print(f"\n  BOUNDARY ERRORS:")
        for btype, count in report.boundary_errors.items():
            print(f"    {btype:<30} {count}")
        print(f"\n  PER-CLASS METRICS:")
        print(f"  {'Class':<12} {'Precision':>10} {'Recall':>10} {'F1':>10}")
        for cls, m in report.per_class_metrics.items():
            print(f"  {cls:<12} {m['precision']:>10.3f} {m['recall']:>10.3f} {m['f1']:>10.3f}")
        if report.ablation_results:
            print(f"\n  ABLATION RESULTS (context channel resolution rates):")
            for ab in report.ablation_results:
                print(f"    {str(ab.channels_enabled):<25} "
                      f"resolved {ab.resolved_count}/{ab.boundary_errors} "
                      f"({ab.resolution_rate:.1%})")
        print(f"{'='*60}\n")

    def _kappa(self, confusion, classes, n) -> float:
        if n == 0:
            return 0.0
        p_o = sum(confusion[c][c] for c in classes) / n
        p_e = sum(
            (sum(confusion[c][x] for x in classes) / n) *
            (sum(confusion[x][c] for x in classes) / n)
            for c in classes
        )
        return (p_o - p_e) / (1 - p_e) if (1 - p_e) > 0 else 0.0

    def _ablation_analysis(self, results: List[ClassificationResult]) -> List[AblationResult]:
        """
        Compute resolution rate for each channel combination.
        This is the core of the H1–H5 ablation study.
        """
        from itertools import combinations

        all_channels = ["h1", "h2", "h3", "h4"]
        ablation_results = []
        boundary_results = [r for r in results if r.is_error and r.context is not None]
        n_boundary = len(boundary_results)

        if n_boundary == 0:
            return []

        for r_len in range(1, len(all_channels) + 1):
            for combo in combinations(all_channels, r_len):
                channels = list(combo)
                resolved = sum(
                    1 for r in boundary_results
                    if r.resolved and r.context and r.context.resolved_by in channels
                )
                errors_after = n_boundary - resolved
                total_errors = len([r for r in results if r.is_error]) - resolved
                accuracy = (len(results) - total_errors) / len(results)
                ablation_results.append(AblationResult(
                    channels_enabled = channels,
                    total_errors     = total_errors,
                    boundary_errors  = n_boundary,
                    resolved_count   = resolved,
                    resolution_rate  = resolved / n_boundary,
                    accuracy         = round(accuracy, 5),
                ))

        return ablation_results

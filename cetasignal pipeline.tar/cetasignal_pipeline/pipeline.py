"""
pipeline.py
───────────
CetaSignal Context Layer Pipeline — main orchestrator.

Runs end-to-end: intake → feature extraction → Layer 1 (cadence)
→ Layer 2 (context) → output logging.

CLI:
    # Single specimen (WAV + JSON metadata)
    python pipeline.py --audio specimen.wav --meta specimen.json

    # Batch directory
    python pipeline.py --batch ./specimens/ --output results.jsonl

    # Error isolation mode — boundary specimens only
    python pipeline.py --batch ./specimens/ --error-mode

    # Hypothesis test — specific context channels
    python pipeline.py --batch ./specimens/ --context h1 h4

    # Direct from acoustic parameters (no audio file needed)
    python pipeline.py --params '{"peakFrequency_hz": 145, "duration_s": 1.2, ...}'
"""

from __future__ import annotations
import argparse
import json
import sys
import os
from pathlib import Path
from typing import Optional, List

# Pipeline modules
from ingestion.specimen_schema import (
    AcousticFeatures, ContextRecord, Specimen, ClassificationResult,
    BehavioralClass, BoundaryType, FreqContour,
    SpatiotemporalFeatures, DepthFeatures, SequenceFeatures, PopulationFeatures,
)
from classifier.cadence_engine import CadenceEngine
from context.context_layer import h5_combined
from output.error_tracker import ErrorTracker


# ─── METADATA PARSER ──────────────────────────────────────────────────────────

def parse_metadata(meta: dict) -> tuple[AcousticFeatures, ContextRecord, Optional[BehavioralClass]]:
    """
    Parse a metadata JSON dict into typed pipeline inputs.

    Expects keys matching CetaSignal specimen format (camelCase from frontend
    or snake_case from Python sources — both accepted).
    """
    af_raw = meta.get("acousticFeatures", meta)

    # Normalize key names (camelCase → snake_case)
    def get(d, *keys):
        for k in keys:
            if k in d:
                return d[k]
        return None

    pf   = get(af_raw, "peakFrequency_hz", "peak_frequency_hz")
    dur  = get(af_raw, "duration_s")
    fc   = get(af_raw, "freqContour", "freq_contour")
    urg  = get(af_raw, "urgencyIndex", "urgency_index")
    freq = get(af_raw, "frequencyRange_hz", "frequency_range_hz")
    ipi  = get(af_raw, "interPulseInterval_ms", "inter_pulse_interval_ms")

    if any(v is None for v in [pf, dur, fc, urg]):
        raise ValueError(f"Missing required acoustic features. Got keys: {list(af_raw.keys())}")

    contour_map = {
        "rising": FreqContour.RISING,
        "descending": FreqContour.DESCENDING,
        "flat": FreqContour.FLAT,
        "complex": FreqContour.COMPLEX,
        "pulsed": FreqContour.PULSED,
    }
    freq_contour = contour_map.get(str(fc).lower(), FreqContour.FLAT)

    acoustic = AcousticFeatures(
        peak_frequency_hz       = float(pf),
        duration_s              = float(dur),
        freq_contour            = freq_contour,
        urgency_index           = float(urg),
        frequency_range_hz      = tuple(freq) if freq else (float(pf)*0.8, float(pf)*1.2),
        inter_pulse_interval_ms = float(ipi) if ipi else None,
    )

    # Context — populated from metadata if available
    context = ContextRecord()

    loc = meta.get("location", meta.get("recordingLocation", {}))
    date = meta.get("recordingDate", meta.get("date", {}))

    if loc and date:
        lat = loc.get("lat", loc.get("latitude"))
        lon = loc.get("lon", loc.get("longitude"))
        year = date.get("year")
        month = date.get("month")
        if all(v is not None for v in [lat, lon, year, month]):
            context.spatiotemporal = SpatiotemporalFeatures(
                latitude=float(lat), longitude=float(lon),
                year=int(year), month=int(month),
                day=date.get("day"),
            )

    depth_raw = meta.get("depth", meta.get("dtag", {}))
    if depth_raw and depth_raw.get("available"):
        context.depth = DepthFeatures(
            depth_at_onset_m    = float(depth_raw.get("depth_onset_m", 0)),
            depth_60s_before_m  = depth_raw.get("depth_60s_m"),
            depth_rate_m_per_s  = depth_raw.get("depth_rate"),
            depth_std_60s       = depth_raw.get("depth_std"),
            inferred_state      = depth_raw.get("state"),
            dtag_available      = True,
        )

    seq_raw = meta.get("sequence", {})
    if seq_raw and seq_raw.get("available"):
        context.sequence = SequenceFeatures(
            n_calls_preceding        = int(seq_raw.get("n_calls", 0)),
            inter_call_interval_mean = seq_raw.get("ici_mean"),
            inter_call_interval_var  = seq_raw.get("ici_var"),
            urgency_gradient         = seq_raw.get("urgency_gradient"),
            response_pattern_index   = seq_raw.get("rpi"),
            window_available         = True,
        )

    pop_raw = meta.get("population", {})
    if pop_raw:
        context.population = PopulationFeatures(
            population_id    = pop_raw.get("id"),
            population_range = pop_raw.get("range"),
            dialect_group    = pop_raw.get("dialect"),
        )

    # Ground truth (held out — only used for error tracking)
    gt_raw = meta.get("groundTruth", meta.get("ground_truth"))
    ground_truth = None
    if gt_raw:
        try:
            ground_truth = BehavioralClass(gt_raw.upper())
        except ValueError:
            pass

    return acoustic, context, ground_truth


# ─── SINGLE SPECIMEN CLASSIFICATION ──────────────────────────────────────────

def classify_specimen(
    acoustic: AcousticFeatures,
    context: ContextRecord,
    ground_truth: Optional[BehavioralClass] = None,
    catalog_id: str = "UNKNOWN",
    species: str = "Unknown",
    context_channels: Optional[List[str]] = None,
) -> ClassificationResult:
    """Run both classification layers for a single specimen."""

    engine = CadenceEngine()
    cadence_result = engine.classify(acoustic)

    # Layer 2 — context refinement
    context_result = None
    if context_channels is not None or context.available_channels():
        channels = context_channels or ["h1", "h2", "h3", "h4"]
        context_result = h5_combined(cadence_result, context, enabled_channels=channels)

    # Determine final prediction
    final_class = (context_result.refined_class
                   if context_result else cadence_result.predicted_class)

    is_error = (ground_truth is not None and final_class != ground_truth)
    resolved = (
        is_error is False and
        context_result is not None and
        context_result.resolved_by is not None and
        cadence_result.predicted_class != final_class
    )

    # Edge: was it a cadence error that context fixed?
    cadence_error = (ground_truth is not None and
                     cadence_result.predicted_class != ground_truth)
    context_fixed = (cadence_error and context_result is not None and
                     context_result.refined_class == ground_truth)
    resolved = context_fixed

    return ClassificationResult(
        catalog_id    = catalog_id,
        species       = species,
        cadence       = cadence_result,
        context       = context_result,
        ground_truth  = ground_truth,
        is_error      = is_error,
        boundary_type = cadence_result.boundary_type,
        resolved      = resolved,
    )


# ─── RESULT PRINTER ───────────────────────────────────────────────────────────

def print_result(result: ClassificationResult) -> None:
    r = result
    cd = r.cadence
    ctx = r.context

    print(f"\n{'─'*60}")
    print(f"  Specimen:    {r.catalog_id} / {r.species}")
    print(f"  {'─'*54}")
    print(f"  LAYER 1 — CADENCE")
    print(f"    Prediction:  {cd.predicted_class.value}")
    print(f"    Confidence:  {cd.confidence:.1%}")
    print(f"    Margin:      {cd.top_two_margin:.1%}")
    print(f"    Boundary:    {cd.boundary_type.value}")
    print(f"  {'─'*54}")
    print(f"  EVIDENCE TRAIL")
    for rule in cd.rule_trace:
        print(f"    [{rule.step}] {rule.rule_name}")
        print(f"        {rule.rationale[:80]}{'...' if len(rule.rationale) > 80 else ''}")
    if ctx:
        print(f"  {'─'*54}")
        print(f"  LAYER 2 — CONTEXT")
        print(f"    Refined:     {ctx.refined_class.value}")
        print(f"    Confidence:  {ctx.context_confidence:.1%}  (Δ {ctx.delta_confidence:+.1%})")
        print(f"    Channels:    {ctx.channels_used or 'none triggered'}")
        print(f"    Resolved by: {ctx.resolved_by or '—'}")
    if r.ground_truth:
        final = ctx.refined_class if ctx else cd.predicted_class
        match = "✓ CORRECT" if final == r.ground_truth else "✗ ERROR"
        print(f"  {'─'*54}")
        print(f"  Ground Truth: {r.ground_truth.value}   {match}")
    print(f"{'─'*60}\n")


# ─── BATCH RUNNER ─────────────────────────────────────────────────────────────

def run_batch(
    batch_dir: str,
    output_path: Optional[str] = None,
    error_mode: bool = False,
    context_channels: Optional[List[str]] = None,
) -> ErrorTracker:
    """Process all .json metadata files in a directory."""
    tracker = ErrorTracker()
    batch = Path(batch_dir)
    files = sorted(batch.glob("*.json"))

    if not files:
        print(f"No JSON files found in {batch_dir}")
        return tracker

    print(f"Processing {len(files)} specimens from {batch_dir}...")

    for f in files:
        try:
            meta = json.loads(f.read_text())
            acoustic, context, ground_truth = parse_metadata(meta)

            result = classify_specimen(
                acoustic        = acoustic,
                context         = context,
                ground_truth    = ground_truth,
                catalog_id      = meta.get("catalogId", f.stem),
                species         = meta.get("species", "Unknown"),
                context_channels = context_channels,
            )

            tracker.add(result)

            if error_mode and result.is_error:
                print_result(result)

        except Exception as e:
            print(f"  [SKIP] {f.name}: {e}")

    tracker.print_summary()

    if output_path:
        tracker.save(output_path)

    return tracker


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="CetaSignal Context Layer Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--audio",   help="Path to WAV/FLAC file")
    parser.add_argument("--meta",    help="Path to JSON metadata file")
    parser.add_argument("--params",  help="JSON string of acoustic parameters (no audio needed)")
    parser.add_argument("--batch",   help="Directory of JSON metadata files for batch processing")
    parser.add_argument("--output",  help="Output path for JSONL results")
    parser.add_argument("--error-mode", action="store_true",
                        help="Print detailed output only for error specimens")
    parser.add_argument("--context", nargs="+", choices=["h1","h2","h3","h4"],
                        help="Context channels to enable (default: all available)")
    parser.add_argument("--ground-truth",
                        help="Ground truth class for single specimen (for error tracking)")

    args = parser.parse_args()

    # ── Batch mode ──
    if args.batch:
        run_batch(
            batch_dir        = args.batch,
            output_path      = args.output,
            error_mode       = args.error_mode,
            context_channels = args.context,
        )
        return

    # ── Single specimen — from params string ──
    if args.params:
        meta = json.loads(args.params)
        if args.ground_truth:
            meta["ground_truth"] = args.ground_truth
        acoustic, context, ground_truth = parse_metadata(meta)
        result = classify_specimen(
            acoustic         = acoustic,
            context          = context,
            ground_truth     = ground_truth,
            context_channels = args.context,
        )
        print_result(result)
        return

    # ── Single specimen — from audio + metadata ──
    if args.meta:
        meta = json.loads(Path(args.meta).read_text())
        if args.ground_truth:
            meta["ground_truth"] = args.ground_truth

        if args.audio:
            # Audio extraction path
            try:
                import numpy as np
                import librosa
                from features.acoustic import AcousticExtractor
                y, sr = librosa.load(args.audio, sr=None, mono=True)
                extractor = AcousticExtractor(sample_rate=sr)
                acoustic = extractor.extract(y)
                print(f"Extracted acoustic features from {args.audio}")
            except ImportError:
                print("librosa not available — falling back to metadata acoustic parameters")
                acoustic, _, _ = parse_metadata(meta)
        else:
            acoustic, _, _ = parse_metadata(meta)

        _, context, ground_truth = parse_metadata(meta)
        result = classify_specimen(
            acoustic         = acoustic,
            context          = context,
            ground_truth     = ground_truth,
            catalog_id       = meta.get("catalogId", "UNKNOWN"),
            species          = meta.get("species", "Unknown"),
            context_channels = args.context,
        )
        print_result(result)
        return

    parser.print_help()


if __name__ == "__main__":
    main()

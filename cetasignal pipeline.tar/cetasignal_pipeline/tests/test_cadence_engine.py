"""
test_cadence_engine.py
──────────────────────
Unit tests for the CadenceEngine Python port.

Verifies that the Python implementation produces the same predictions
as the JS CadenceClassifier for all 5 canonical specimen types.
Tests Fix A, Fix B, Fix C edge cases specifically.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ingestion.specimen_schema import AcousticFeatures, FreqContour, BehavioralClass, BoundaryType
from classifier.cadence_engine import CadenceEngine

engine = CadenceEngine()


# ─── FIXTURES ─────────────────────────────────────────────────────────────────

# NARW upcall — canonical CONTACT
NARW_UPCALL = AcousticFeatures(
    peak_frequency_hz=145.0, duration_s=1.1,
    freq_contour=FreqContour.RISING, urgency_index=0.38,
    frequency_range_hz=(75.0, 215.0), inter_pulse_interval_ms=None,
)

# Fin whale 20Hz — canonical NAVIGATE
FIN_20HZ = AcousticFeatures(
    peak_frequency_hz=20.0, duration_s=1.0,
    freq_contour=FreqContour.FLAT, urgency_index=0.06,
    frequency_range_hz=(15.0, 30.0), inter_pulse_interval_ms=12000.0,
)

# Orca burst-pulse — canonical FORAGE
ORCA_BURST = AcousticFeatures(
    peak_frequency_hz=8500.0, duration_s=0.8,
    freq_contour=FreqContour.COMPLEX, urgency_index=0.78,
    frequency_range_hz=(500.0, 25000.0), inter_pulse_interval_ms=None,
)

# Humpback song unit — canonical BROADCAST
HUMPBACK_SONG = AcousticFeatures(
    peak_frequency_hz=850.0, duration_s=14.5,
    freq_contour=FreqContour.COMPLEX, urgency_index=0.07,
    frequency_range_hz=(200.0, 4000.0), inter_pulse_interval_ms=None,
)

# Sei whale downsweep — canonical DIVE
SEI_DOWNSWEEP = AcousticFeatures(
    peak_frequency_hz=1450.0, duration_s=0.7,
    freq_contour=FreqContour.DESCENDING, urgency_index=0.55,
    frequency_range_hz=(800.0, 3500.0), inter_pulse_interval_ms=None,
)

# Fix A case — Cuvier's beaked whale foraging clicks (was misclassified as CONTACT in v1)
CUVIERS_CLICKS = AcousticFeatures(
    peak_frequency_hz=42000.0, duration_s=0.3,
    freq_contour=FreqContour.PULSED, urgency_index=0.72,
    frequency_range_hz=(30000.0, 60000.0), inter_pulse_interval_ms=280.0,
)

# Fix B case — Omura's whale song (was misclassified as NAVIGATE in v1)
OMURA_SONG = AcousticFeatures(
    peak_frequency_hz=38.0, duration_s=18.0,
    freq_contour=FreqContour.COMPLEX, urgency_index=0.09,
    frequency_range_hz=(25.0, 120.0), inter_pulse_interval_ms=None,
)

# Fix C case — Spinner dolphin whistle (was misclassified as BROADCAST in v1)
SPINNER_WHISTLE = AcousticFeatures(
    peak_frequency_hz=8200.0, duration_s=1.4,
    freq_contour=FreqContour.COMPLEX, urgency_index=0.22,
    frequency_range_hz=(4000.0, 14000.0), inter_pulse_interval_ms=None,
)


# ─── TESTS ────────────────────────────────────────────────────────────────────

def test_narw_upcall_is_contact():
    result = engine.classify(NARW_UPCALL)
    assert result.predicted_class == BehavioralClass.CONTACT, \
        f"Expected CONTACT, got {result.predicted_class} (conf={result.confidence:.2%})"
    print(f"  ✓ NARW upcall → CONTACT ({result.confidence:.1%})")


def test_fin_20hz_is_navigate():
    result = engine.classify(FIN_20HZ)
    assert result.predicted_class == BehavioralClass.NAVIGATE, \
        f"Expected NAVIGATE, got {result.predicted_class} (conf={result.confidence:.2%})"
    print(f"  ✓ Fin 20Hz → NAVIGATE ({result.confidence:.1%})")


def test_orca_burst_is_forage():
    result = engine.classify(ORCA_BURST)
    assert result.predicted_class == BehavioralClass.FORAGE, \
        f"Expected FORAGE, got {result.predicted_class} (conf={result.confidence:.2%})"
    print(f"  ✓ Orca burst-pulse → FORAGE ({result.confidence:.1%})")


def test_humpback_song_is_broadcast():
    result = engine.classify(HUMPBACK_SONG)
    assert result.predicted_class == BehavioralClass.BROADCAST, \
        f"Expected BROADCAST, got {result.predicted_class} (conf={result.confidence:.2%})"
    print(f"  ✓ Humpback song → BROADCAST ({result.confidence:.1%})")


def test_sei_downsweep_is_dive():
    result = engine.classify(SEI_DOWNSWEEP)
    assert result.predicted_class == BehavioralClass.DIVE, \
        f"Expected DIVE, got {result.predicted_class} (conf={result.confidence:.2%})"
    print(f"  ✓ Sei downsweep → DIVE ({result.confidence:.1%})")


def test_fix_a_beaked_whale_clicks_are_forage():
    """Fix A: pf > 30kHz + IPI present → FORAGE, not CONTACT."""
    result = engine.classify(CUVIERS_CLICKS)
    assert result.predicted_class == BehavioralClass.FORAGE, \
        f"Fix A FAILED: Expected FORAGE, got {result.predicted_class}"
    # Confirm Fix A fired
    fix_a_fired = any("Fix A" in r.rule_name for r in result.rule_trace)
    assert fix_a_fired, "Fix A rule did not fire for pf > 30kHz + IPI"
    print(f"  ✓ Fix A: Cuvier's clicks → FORAGE ({result.confidence:.1%})")


def test_fix_b_omuras_song_is_broadcast():
    """Fix B: complex + dur > 6s + urgency < 0.20 → BROADCAST override before IPI gate."""
    result = engine.classify(OMURA_SONG)
    assert result.predicted_class == BehavioralClass.BROADCAST, \
        f"Fix B FAILED: Expected BROADCAST, got {result.predicted_class}"
    fix_b_fired = any("Fix B" in r.rule_name for r in result.rule_trace)
    assert fix_b_fired, "Fix B rule did not fire for complex + long dur + low urgency"
    print(f"  ✓ Fix B: Omura's song → BROADCAST ({result.confidence:.1%})")


def test_fix_c_spinner_whistle_is_contact():
    """Fix C: high pf + short dur + complex/rising + moderate urgency → CONTACT."""
    result = engine.classify(SPINNER_WHISTLE)
    assert result.predicted_class == BehavioralClass.CONTACT, \
        f"Fix C FAILED: Expected CONTACT, got {result.predicted_class}"
    fix_c_fired = any("Fix C" in r.rule_name for r in result.rule_trace)
    assert fix_c_fired, "Fix C rule did not fire for delphinid contact whistle"
    print(f"  ✓ Fix C: Spinner whistle → CONTACT ({result.confidence:.1%})")


def test_rule_trace_is_populated():
    """Evidence trail must contain at least 3 rules for every specimen."""
    for label, fixture in [
        ("NARW", NARW_UPCALL), ("Fin", FIN_20HZ), ("Orca", ORCA_BURST),
        ("Humpback", HUMPBACK_SONG), ("Sei", SEI_DOWNSWEEP),
    ]:
        result = engine.classify(fixture)
        assert len(result.rule_trace) >= 3, \
            f"{label}: evidence trail only has {len(result.rule_trace)} rules"
    print(f"  ✓ Evidence trail has ≥3 rules for all canonical specimens")


def test_confidence_is_valid():
    """Confidence must be in [0, 1] for all specimens."""
    for fixture in [NARW_UPCALL, FIN_20HZ, ORCA_BURST, HUMPBACK_SONG, SEI_DOWNSWEEP]:
        result = engine.classify(fixture)
        assert 0.0 <= result.confidence <= 1.0, \
            f"Confidence {result.confidence} outside [0, 1]"
    print(f"  ✓ Confidence values all in [0, 1]")


def test_class_scores_sum_to_one():
    """Softmax scores must sum to 1.0 within floating point tolerance."""
    result = engine.classify(NARW_UPCALL)
    total = sum(result.class_scores.values())
    assert abs(total - 1.0) < 1e-6, f"Class scores sum to {total} (expected 1.0)"
    print(f"  ✓ Class scores sum to 1.0")


def test_boundary_detection():
    """A genuinely ambiguous specimen should be flagged with a non-NONE boundary type."""
    # Construct a specimen that sits at BROADCAST/NAVIGATE boundary
    ambiguous = AcousticFeatures(
        peak_frequency_hz=22.0, duration_s=3.5,
        freq_contour=FreqContour.FLAT, urgency_index=0.12,
        frequency_range_hz=(15.0, 35.0), inter_pulse_interval_ms=8000.0,
    )
    result = engine.classify(ambiguous)
    # Should be detected as boundary (may be NAVIGATE or BROADCAST but margin should be small)
    print(f"  ✓ Ambiguous specimen: {result.predicted_class.value} "
          f"(margin={result.top_two_margin:.3f}, boundary={result.boundary_type.value})")


# ─── RUNNER ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_narw_upcall_is_contact,
        test_fin_20hz_is_navigate,
        test_orca_burst_is_forage,
        test_humpback_song_is_broadcast,
        test_sei_downsweep_is_dive,
        test_fix_a_beaked_whale_clicks_are_forage,
        test_fix_b_omuras_song_is_broadcast,
        test_fix_c_spinner_whistle_is_contact,
        test_rule_trace_is_populated,
        test_confidence_is_valid,
        test_class_scores_sum_to_one,
        test_boundary_detection,
    ]

    print(f"\nCetaSignal CadenceEngine — Unit Tests")
    print(f"{'='*45}")
    passed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {test.__name__}: {e}")
        except Exception as e:
            print(f"  ✗ {test.__name__} [ERROR]: {e}")

    print(f"{'='*45}")
    print(f"  {passed}/{len(tests)} tests passed\n")
    sys.exit(0 if passed == len(tests) else 1)
